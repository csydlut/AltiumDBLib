Place here Altium Design Files
After release, keep record about any required changes in TODO directory.