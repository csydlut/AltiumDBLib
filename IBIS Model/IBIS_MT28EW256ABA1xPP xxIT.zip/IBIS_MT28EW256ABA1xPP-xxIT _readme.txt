
mt28ew256aba_3p0_it.ibs * IBIS 4.2 Model
This Model is valid for AT Temperature Range -40C<=Ta<=85C
2.7-3.6 Volt power supply range

mt28ew256aba_1p8_it.ibs * IBIS 4.2 Model
This Model is valid for IT Temperature Range -40C<=Ta<=85C
1.65-1.95 Volt power supply range

-------------------------------------------------------------------------------------

256 Mbit 45nm Parallel Flash Memory
Rev Mask Code A

=====================================================================================

This model is valid for multiple Part Numbers.
Verify valid part numbers by using Microns part catalog search at www.micron.com. 
To compare features and specifications by device type, visit www.micron.com/products. 
Contact the factory for devices not found.



MT28EW256ABA1xPP-xxIT

x.1=  x16

PP= package codes: JS, PC, PN
	JS = 56-pin TSOP, 14 x 20mm
    PC = 64-ball LBGA, 11 x 13mm
	PN = 56-Ball VFBGA, 7mm x 9mm
	 
IT= temperature range
        IT= -40C to +85C 
